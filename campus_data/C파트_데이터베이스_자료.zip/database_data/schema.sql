PRAGMA foreign_keys=ON;

CREATE TABLE sources (
  source_id TEXT PRIMARY KEY,
  kind TEXT,
  title TEXT,
  location TEXT,
  collected_at_original TEXT,
  review_status TEXT
);

CREATE TABLE colleges (
  college_id TEXT PRIMARY KEY,
  name TEXT NOT NULL
);

CREATE TABLE departments (
  department_id TEXT PRIMARY KEY,
  name TEXT,
  college_id TEXT REFERENCES colleges(college_id),
  program_type TEXT,
  review_status TEXT
);

CREATE TABLE department_source_codes (
  mapping_id TEXT PRIMARY KEY,
  department_id TEXT REFERENCES departments(department_id),
  source_id TEXT REFERENCES sources(source_id),
  external_code TEXT
);

CREATE TABLE terms (
  term_id TEXT PRIMARY KEY,
  academic_year INTEGER,
  semester INTEGER
);

CREATE TABLE courses (
  course_id TEXT PRIMARY KEY,
  course_code TEXT,
  display_name TEXT,
  identity_status TEXT
);

CREATE TABLE offerings (
  offering_id TEXT PRIMARY KEY,
  term_id TEXT REFERENCES terms(term_id),
  course_id TEXT REFERENCES courses(course_id),
  course_number TEXT,
  section TEXT,
  name_original TEXT,
  department_id TEXT REFERENCES departments(department_id),
  professor_original TEXT,
  credits REAL,
  category TEXT,
  cancelled INTEGER,
  time_status TEXT,
  source_id TEXT REFERENCES sources(source_id)
);

CREATE TABLE offering_target_grades (
  id TEXT PRIMARY KEY,
  offering_id TEXT REFERENCES offerings(offering_id),
  grade INTEGER
);

CREATE TABLE offering_originals (
  offering_id TEXT PRIMARY KEY REFERENCES offerings(offering_id),
  time_original TEXT,
  intensive_original TEXT,
  category_original TEXT,
  target_grades_original TEXT,
  department_code_original TEXT,
  eligible_departments_original TEXT,
  enrollment_notes TEXT,
  remarks_original TEXT,
  lecture_type_original TEXT,
  record_json TEXT
);

CREATE TABLE buildings (
  building_id TEXT PRIMARY KEY,
  name_observed TEXT,
  official_name TEXT,
  review_status TEXT
);

CREATE TABLE rooms (
  room_id TEXT PRIMARY KEY,
  building_id TEXT REFERENCES buildings(building_id),
  room_number TEXT,
  floor TEXT,
  review_status TEXT
);

CREATE TABLE locations (
  location_id TEXT PRIMARY KEY,
  label_original TEXT,
  building_id TEXT REFERENCES buildings(building_id),
  room_id TEXT REFERENCES rooms(room_id),
  location_type TEXT,
  review_status TEXT
);

CREATE TABLE entrances (
  entrance_id TEXT PRIMARY KEY,
  building_id TEXT REFERENCES buildings(building_id),
  name TEXT,
  latitude REAL,
  longitude REAL,
  source_id TEXT REFERENCES sources(source_id),
  review_status TEXT
);

CREATE TABLE travel_routes (
  route_id TEXT PRIMARY KEY,
  from_entrance_id TEXT REFERENCES entrances(entrance_id),
  to_entrance_id TEXT REFERENCES entrances(entrance_id),
  mode TEXT,
  distance_m REAL,
  duration_seconds INTEGER,
  source_id TEXT REFERENCES sources(source_id),
  observed_at TEXT,
  review_status TEXT
);

CREATE TABLE sessions (
  session_id TEXT PRIMARY KEY,
  offering_id TEXT REFERENCES offerings(offering_id),
  day TEXT,
  start_time TEXT,
  end_time TEXT,
  location_id TEXT REFERENCES locations(location_id),
  delivery_mode TEXT
);

CREATE TABLE session_weeks (
  id TEXT PRIMARY KEY,
  session_id TEXT REFERENCES sessions(session_id),
  week INTEGER,
  basis TEXT
);

CREATE TABLE curricula (
  curriculum_id TEXT PRIMARY KEY,
  department_id TEXT REFERENCES departments(department_id),
  curriculum_year INTEGER,
  admission_year INTEGER,
  degree_type_requested TEXT,
  single_major_applicability TEXT,
  application_status TEXT,
  source_id TEXT REFERENCES sources(source_id)
);

CREATE TABLE curriculum_courses (
  curriculum_course_id TEXT PRIMARY KEY,
  curriculum_id TEXT REFERENCES curricula(curriculum_id),
  course_id TEXT REFERENCES courses(course_id),
  name_original TEXT,
  category TEXT,
  credits REAL,
  recommended_grade INTEGER,
  required INTEGER,
  source_pdf_page INTEGER
);

CREATE TABLE curriculum_course_semesters (
  id TEXT PRIMARY KEY,
  curriculum_course_id TEXT REFERENCES curriculum_courses(curriculum_course_id),
  semester INTEGER
);

CREATE TABLE credit_requirements (
  id TEXT PRIMARY KEY,
  curriculum_id TEXT REFERENCES curricula(curriculum_id),
  requirement_type TEXT,
  minimum_credits REAL,
  source_pdf_page INTEGER,
  review_status TEXT
);

CREATE TABLE additional_requirements (
  requirement_id TEXT PRIMARY KEY,
  curriculum_id TEXT REFERENCES curricula(curriculum_id),
  description_original TEXT,
  source_pdf_page INTEGER,
  evaluation_status TEXT
);

CREATE TABLE unresolved_requirements (
  id TEXT PRIMARY KEY,
  curriculum_id TEXT REFERENCES curricula(curriculum_id),
  description TEXT,
  status TEXT
);

CREATE TABLE curriculum_originals (
  curriculum_id TEXT PRIMARY KEY REFERENCES curricula(curriculum_id),
  record_json TEXT
);

CREATE TABLE source_evidence (
  evidence_id TEXT PRIMARY KEY,
  entity_table TEXT,
  entity_id TEXT,
  source_id TEXT REFERENCES sources(source_id),
  source_pdf_page INTEGER,
  description TEXT
);

CREATE TABLE review_issues (
  issue_id TEXT PRIMARY KEY,
  entity_table TEXT,
  entity_id TEXT,
  description TEXT,
  status TEXT
);
